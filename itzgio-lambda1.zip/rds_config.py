#config file containing credentials for rds mysql instance
db_username = "giorgio"
db_password = "Contra1234."
db_name = "itzgiodb" 
