import sys
import logging
import rds_config
import pymysql
import os
#rds settings
rds_host  = os.environ['DbEndpoint']
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, port=3306, user=name, passwd=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
def handler(event, context):
    """
    This function initializes the schema of a db instance
    """

    item_count = 0

    with conn.cursor() as cur:
        cur.execute("create table Image (ID int NOT NULL AUTO_INCREMENT, Name varchar(255) NOT NULL, TagName varchar(255), TagValue varchar(255), ImageUrl varchar(255), PRIMARY KEY (ID))")
        conn.commit()

    return "Database schema created"
